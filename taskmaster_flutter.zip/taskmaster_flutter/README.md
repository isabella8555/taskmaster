# TASKMASTER

Primeira versão visual do projeto de lista de tarefas em Flutter/Dart.

Esta versão **não usa Firebase**. Os dados ficam apenas em memória e são reiniciados quando o aplicativo é fechado. A integração com Firebase será feita em uma etapa posterior.

## Como executar

1. Instale o Flutter SDK e configure o VS Code com as extensões Flutter e Dart.
2. Abra esta pasta no VS Code.
3. Execute no terminal:

```bash
flutter pub get
flutter run -d chrome
```

Para executar no computador, use um dispositivo desktop disponível, por exemplo:

```bash
flutter run -d windows
# ou
flutter run -d linux
```

## O que já está funcionando

- Dashboard com contadores de tarefas.
- Cadastro de tarefas.
- Edição de tarefas.
- Exclusão de tarefas.
- Alteração de status.
- Busca por título e descrição.
- Filtro por status, prioridade e categoria.
- Ordenação por prioridade.
- Tema azul-marinho e roxo.
- Layout adaptável para telas largas e estreitas.

## Próxima etapa

Substituir a lista temporária em `lib/main.dart` por um serviço de dados usando Firebase Cloud Firestore. A interface poderá ser mantida praticamente igual.

## Organização das pastas

```text
lib/
├── main.dart                 # Inicialização do app e MaterialApp
├── models/task.dart          # Modelo e enums da tarefa
├── screens/home_screen.dart  # Dashboard e estado principal
├── dialogs/                  # Formulários exibidos em diálogo
├── widgets/                  # Componentes visuais reutilizáveis
├── theme/app_theme.dart      # Tema global da aplicação
├── data/mock_tasks.dart      # Dados temporários da primeira versão
└── utils/task_labels.dart    # Textos e formatação
```

Quando o Firebase for adicionado, será criada uma pasta `services/` para concentrar o acesso ao Firestore sem misturar banco de dados com a interface.

## Áreas adicionadas nesta versão

- **Todas as tarefas**: lista completa com edição, exclusão e mudança de status.
- **Calendário**: calendário mensal fictício, navegação entre meses e tarefas agrupadas por dia.
- **Notificações**: painel fictício aberto pelo sino no cabeçalho.

A navegação funciona pela barra lateral em telas largas e pela barra inferior em telas menores.

## Configurações

A tela de configurações agora inclui:

- FAQ com perguntas e respostas prontas;
- Edição local do nome, e-mail e descrição do perfil;
- Alternância entre modo noite e modo dia;
- Navegação pela barra lateral e pela barra inferior em telas menores.

As alterações ainda ficam em memória. O Firebase poderá persistir o perfil e as preferências posteriormente.
