import 'package:flutter/material.dart';
import '../models/task.dart';
import '../utils/task_labels.dart';

class TaskFormDialog extends StatefulWidget {
  final Task? task;
  const TaskFormDialog({super.key, this.task});
  @override
  State<TaskFormDialog> createState() => _TaskFormDialogState();
}

class _TaskFormDialogState extends State<TaskFormDialog> {
  late final TextEditingController _title;
  late final TextEditingController _description;
  late TaskCategory _category;
  late TaskPriority _priority;
  DateTime? _dueDate;

  @override
  void initState() {
    super.initState();
    final task = widget.task;
    _title = TextEditingController(text: task?.title);
    _description = TextEditingController(text: task?.description);
    _category = task?.category ?? TaskCategory.studies;
    _priority = task?.priority ?? TaskPriority.medium;
    _dueDate = task?.dueDate;
  }

  @override
  void dispose() { _title.dispose(); _description.dispose(); super.dispose(); }

  Future<void> _pickDate() async {
    final date = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: _dueDate ?? DateTime.now());
    if (date != null) setState(() => _dueDate = date);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.task == null ? 'Adicionar tarefa' : 'Editar tarefa'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: _title, autofocus: true, decoration: const InputDecoration(labelText: 'Título *')),
              const SizedBox(height: 14),
              TextField(controller: _description, maxLines: 3, decoration: const InputDecoration(labelText: 'Descrição')),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: DropdownButtonFormField<TaskCategory>(initialValue: _category, decoration: const InputDecoration(labelText: 'Categoria'), items: TaskCategory.values.map((c) => DropdownMenuItem(value: c, child: Text(categoryLabel(c)))).toList(), onChanged: (v) => setState(() => _category = v!))),
                const SizedBox(width: 12),
                Expanded(child: DropdownButtonFormField<TaskPriority>(initialValue: _priority, decoration: const InputDecoration(labelText: 'Prioridade'), items: TaskPriority.values.map((p) => DropdownMenuItem(value: p, child: Text(priorityLabel(p)))).toList(), onChanged: (v) => setState(() => _priority = v!))),
              ]),
              const SizedBox(height: 14),
              OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), label: Text(_dueDate == null ? 'Escolher prazo' : formatDate(_dueDate!))),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () {
              if (_title.text.trim().isEmpty) return;
              Navigator.pop(context, Task(title: _title.text.trim(), description: _description.text.trim(), category: _category, priority: _priority, status: widget.task?.status ?? TaskStatus.pending, dueDate: _dueDate));
            },
            child: const Text('Salvar'),
          ),
        ],
      );
}
