import '../models/task.dart';

class MockTasks {
  static List<Task> initial() => [
        Task(
          title: 'Finalizar trabalho escolar',
          description: 'Revisar o conteúdo e enviar a versão final.',
          category: TaskCategory.studies,
          priority: TaskPriority.high,
          status: TaskStatus.inProgress,
          dueDate: DateTime(2026, 10, 20),
        ),
        Task(
          title: 'Organizar reunião da equipe',
          description: 'Definir pauta e enviar o convite aos participantes.',
          category: TaskCategory.work,
          priority: TaskPriority.medium,
          status: TaskStatus.pending,
          dueDate: DateTime(2026, 10, 24),
        ),
        Task(
          title: 'Fazer caminhada',
          description: 'Caminhar por pelo menos 30 minutos.',
          category: TaskCategory.health,
          priority: TaskPriority.low,
          status: TaskStatus.completed,
        ),
      ];
}
