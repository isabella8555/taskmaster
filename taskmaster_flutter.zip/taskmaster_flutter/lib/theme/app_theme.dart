import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark, surface: const Color(0xFF151E31)),
        scaffoldBackgroundColor: const Color(0xFF0B1220),
        fontFamily: 'Arial',
        inputDecorationTheme: _inputs(const Color(0xFF1C2840)),
      );

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7652D6), brightness: Brightness.light, surface: Colors.white),
        scaffoldBackgroundColor: const Color(0xFFF4F5FB),
        fontFamily: 'Arial',
        inputDecorationTheme: _inputs(Colors.white),
      );

  static InputDecorationTheme _inputs(Color fillColor) => InputDecorationTheme(
        filled: true,
        fillColor: fillColor,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      );
}
