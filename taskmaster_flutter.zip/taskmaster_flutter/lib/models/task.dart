enum TaskPriority { high, medium, low }
enum TaskStatus { pending, inProgress, completed }
enum TaskCategory { studies, work, personal, health, other }

class Task {
  Task({
    required this.title,
    required this.description,
    required this.category,
    required this.priority,
    required this.status,
    this.dueDate,
  });

  String title;
  String description;
  TaskCategory category;
  TaskPriority priority;
  TaskStatus status;
  DateTime? dueDate;
}
