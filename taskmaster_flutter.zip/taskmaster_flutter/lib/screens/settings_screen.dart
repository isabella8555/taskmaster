import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  final String name;
  final String email;
  final String about;
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;
  final void Function(String name, String email, String about) onProfileSaved;

  const SettingsScreen({super.key, required this.name, required this.email, required this.about, required this.isDarkMode, required this.onThemeChanged, required this.onProfileSaved});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _name;
  late final TextEditingController _email;
  late final TextEditingController _about;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.name);
    _email = TextEditingController(text: widget.email);
    _about = TextEditingController(text: widget.about);
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _about.dispose();
    super.dispose();
  }

  void _saveProfile() {
    if (_name.text.trim().isEmpty) return;
    widget.onProfileSaved(_name.text.trim(), _email.text.trim(), _about.text.trim());
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Perfil atualizado com sucesso.')));
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Configurações', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Personalize seu perfil e a experiência do TASKMASTER.', style: TextStyle(color: Colors.blueGrey.shade200)),
        const SizedBox(height: 26),
        _sectionTitle(Icons.person_outline, 'Meu perfil'),
        const SizedBox(height: 12),
        _card(Column(children: [
          Row(children: [
            const CircleAvatar(radius: 34, backgroundColor: Color(0xFF33245E), child: Icon(Icons.person, size: 34, color: Color(0xFFB49BFF))),
            const SizedBox(width: 18),
            Expanded(child: Text('Atualize suas informações para deixar seu espaço mais pessoal.', style: TextStyle(color: Colors.blueGrey.shade200))),
          ]),
          const SizedBox(height: 20),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nome', prefixIcon: Icon(Icons.badge_outlined))),
          const SizedBox(height: 12),
          TextField(controller: _email, decoration: const InputDecoration(labelText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
          const SizedBox(height: 12),
          TextField(controller: _about, maxLines: 3, decoration: const InputDecoration(labelText: 'Sobre você', prefixIcon: Icon(Icons.notes_outlined))),
          const SizedBox(height: 16),
          Align(alignment: Alignment.centerRight, child: FilledButton.icon(onPressed: _saveProfile, icon: const Icon(Icons.save_outlined), label: const Text('Salvar perfil'))),
        ])),
        const SizedBox(height: 28),
        _sectionTitle(Icons.palette_outlined, 'Aparência'),
        const SizedBox(height: 12),
        _card(SwitchListTile.adaptive(contentPadding: EdgeInsets.zero, title: const Text('Modo noite'), subtitle: Text(widget.isDarkMode ? 'Tema escuro ativado' : 'Tema claro ativado'), secondary: Icon(widget.isDarkMode ? Icons.dark_mode_outlined : Icons.light_mode_outlined), value: widget.isDarkMode, onChanged: widget.onThemeChanged)),
        const SizedBox(height: 28),
        _sectionTitle(Icons.help_outline, 'Central de ajuda'),
        const SizedBox(height: 12),
        _card(const Column(children: [
          _Faq(question: 'Como cadastrar uma tarefa?', answer: 'Use o botão Adicionar tarefa no canto inferior da tela, preencha os campos e toque em Salvar.'),
          _Faq(question: 'Como alterar o status?', answer: 'Abra o menu de status no cartão da tarefa e escolha Pendente, Em andamento ou Concluída.'),
          _Faq(question: 'Meus dados já estão salvos na nuvem?', answer: 'Ainda não. Esta versão usa dados fictícios em memória. O Firebase será conectado na próxima etapa.'),
          _Faq(question: 'Posso visualizar meus prazos?', answer: 'Sim. Acesse Calendário no menu lateral para navegar pelos meses e consultar os prazos.'),
        ])),
      ]);

  Widget _sectionTitle(IconData icon, String title) => Row(children: [Icon(icon, color: const Color(0xFFB49BFF)), const SizedBox(width: 10), Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))]);
  Widget _card(Widget child) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .35)),
        ),
        child: Material(color: Colors.transparent, child: child),
      );
}

class _Faq extends StatelessWidget {
  final String question;
  final String answer;
  const _Faq({required this.question, required this.answer});
  @override
  Widget build(BuildContext context) => ExpansionTile(title: Text(question), leading: const Icon(Icons.question_answer_outlined, size: 20), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14), children: [Align(alignment: Alignment.centerLeft, child: Text(answer, style: TextStyle(color: Colors.blueGrey.shade300)))]);
}
