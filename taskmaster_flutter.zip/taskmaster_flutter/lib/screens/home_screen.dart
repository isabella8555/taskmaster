import 'package:flutter/material.dart';
import '../data/mock_tasks.dart';
import '../dialogs/task_form_dialog.dart';
import '../models/task.dart';
import '../utils/task_labels.dart';
import '../widgets/empty_state.dart';
import '../widgets/filter_dropdown.dart';
import '../widgets/notification_panel.dart';
import '../widgets/sidebar.dart';
import '../widgets/summary_card.dart';
import '../widgets/task_card.dart';
import 'all_tasks_screen.dart';
import 'calendar_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;
  const HomeScreen({super.key, required this.isDarkMode, required this.onThemeChanged});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Task> _tasks = MockTasks.initial();
  AppSection _section = AppSection.dashboard;
  String _search = '';
  TaskStatus? _statusFilter;
  TaskPriority? _priorityFilter;
  TaskCategory? _categoryFilter;
  bool _sortByPriority = true;
  String _profileName = 'Alex';
  String _profileEmail = 'alex@taskmaster.com';
  String _profileAbout = 'Organizando meu dia com mais foco.';

  List<Task> get _visibleTasks {
    final query = _search.toLowerCase();
    final result = _tasks.where((task) => (task.title.toLowerCase().contains(query) || task.description.toLowerCase().contains(query)) && (_statusFilter == null || task.status == _statusFilter) && (_priorityFilter == null || task.priority == _priorityFilter) && (_categoryFilter == null || task.category == _categoryFilter)).toList();
    if (_sortByPriority) result.sort((a, b) => a.priority.index.compareTo(b.priority.index));
    return result;
  }

  Future<void> _openTaskForm([Task? task]) async {
    final edited = await showDialog<Task>(context: context, builder: (_) => TaskFormDialog(task: task));
    if (edited == null) return;
    setState(() { if (task == null) { _tasks.insert(0, edited); } else { _tasks[_tasks.indexOf(task)] = edited; } });
  }

  void _deleteTask(Task task) {
    setState(() => _tasks.remove(task));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tarefa excluída.')));
  }

  void _showNotifications() => showDialog<void>(context: context, builder: (_) => const NotificationPanel());

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
          final wide = constraints.maxWidth >= 850;
          return Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            if (wide) SideBar(selected: _section, onSelected: (section) => setState(() => _section = section)),
            Expanded(child: SingleChildScrollView(padding: EdgeInsets.symmetric(horizontal: wide ? 42 : 18, vertical: 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _header(wide), const SizedBox(height: 28),
              if (_section == AppSection.dashboard) _dashboard() else if (_section == AppSection.allTasks) AllTasksScreen(tasks: _tasks, onEdit: _openTaskForm, onDelete: _deleteTask, onChanged: (_) => setState(() {})) else if (_section == AppSection.calendar) CalendarScreen(tasks: _tasks) else SettingsScreen(name: _profileName, email: _profileEmail, about: _profileAbout, isDarkMode: widget.isDarkMode, onThemeChanged: widget.onThemeChanged, onProfileSaved: (name, email, about) => setState(() { _profileName = name; _profileEmail = email; _profileAbout = about; })),
            ]))),
          ]);
        })),
        bottomNavigationBar: MediaQuery.of(context).size.width < 850
            ? NavigationBar(
                selectedIndex: _section.index,
                onDestinationSelected: (index) => setState(() => _section = AppSection.values[index]),
                destinations: const [
                  NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Início'),
                  NavigationDestination(icon: Icon(Icons.list_alt_outlined), label: 'Tarefas'),
                  NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Calendário'),
                  NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Configurações'),
                ],
              )
            : null,
        floatingActionButton: _section == AppSection.calendar || _section == AppSection.settings ? null : FloatingActionButton.extended(onPressed: _openTaskForm, backgroundColor: const Color(0xFF8B5CF6), icon: const Icon(Icons.add), label: const Text('Adicionar tarefa')),
      );

  Widget _header(bool wide) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    if (!wide) ...[const Icon(Icons.check_circle_outline, color: Color(0xFF9B7BFF), size: 36), const SizedBox(width: 12)],
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_section == AppSection.dashboard ? 'Olá, $_profileName!' : _section == AppSection.allTasks ? 'Central de tarefas' : _section == AppSection.calendar ? 'Sua agenda' : 'Preferências', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('Organize seu dia e mantenha o foco no que importa.', style: TextStyle(color: Colors.blueGrey.shade200))])),
    IconButton(tooltip: 'Notificações', onPressed: _showNotifications, icon: const Icon(Icons.notifications_none)),
    const CircleAvatar(radius: 22, backgroundColor: Color(0xFF33245E), child: Text('A', style: TextStyle(fontWeight: FontWeight.bold))),
  ]);

  Widget _dashboard() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_summary(), const SizedBox(height: 32), _toolbar(), const SizedBox(height: 20), if (_visibleTasks.isEmpty) const EmptyState() else ..._visibleTasks.map((task) => Padding(padding: const EdgeInsets.only(bottom: 14), child: TaskCard(task: task, onEdit: () => _openTaskForm(task), onDelete: () => _deleteTask(task), onStatusChanged: (status) => setState(() => task.status = status ?? task.status))))]);

  Widget _summary() => LayoutBuilder(builder: (context, constraints) {
    final cards = [SummaryCard('Pendentes', _tasks.where((t) => t.status == TaskStatus.pending).length, Icons.schedule, const Color(0xFFF59E0B)), SummaryCard('Em andamento', _tasks.where((t) => t.status == TaskStatus.inProgress).length, Icons.autorenew, const Color(0xFF60A5FA)), SummaryCard('Concluídas', _tasks.where((t) => t.status == TaskStatus.completed).length, Icons.check_circle_outline, const Color(0xFF34D399))];
    return constraints.maxWidth < 600 ? Column(children: cards.map((card) => Padding(padding: const EdgeInsets.only(bottom: 12), child: card)).toList()) : Row(children: cards.map((card) => Expanded(child: Padding(padding: const EdgeInsets.only(right: 14), child: card))).toList());
  });

  Widget _toolbar() => Column(children: [Row(children: [Expanded(child: TextField(onChanged: (value) => setState(() => _search = value), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar tarefas...'))), const SizedBox(width: 12), IconButton.filledTonal(tooltip: 'Ordenar por prioridade', onPressed: () => setState(() => _sortByPriority = !_sortByPriority), icon: Icon(_sortByPriority ? Icons.sort : Icons.sort_by_alpha))]), const SizedBox(height: 12), Wrap(spacing: 8, runSpacing: 8, children: [FilterDropdown<TaskStatus>(label: 'Status', value: _statusFilter, items: TaskStatus.values, text: statusLabel, onChanged: (value) => setState(() => _statusFilter = value)), FilterDropdown<TaskPriority>(label: 'Prioridade', value: _priorityFilter, items: TaskPriority.values, text: priorityLabel, onChanged: (value) => setState(() => _priorityFilter = value)), FilterDropdown<TaskCategory>(label: 'Categoria', value: _categoryFilter, items: TaskCategory.values, text: categoryLabel, onChanged: (value) => setState(() => _categoryFilter = value))])]);
}
