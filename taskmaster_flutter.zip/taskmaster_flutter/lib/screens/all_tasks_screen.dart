import 'package:flutter/material.dart';
import '../models/task.dart';
import '../widgets/task_card.dart';
import '../widgets/empty_state.dart';

class AllTasksScreen extends StatelessWidget {
  final List<Task> tasks;
  final ValueChanged<Task> onEdit;
  final ValueChanged<Task> onDelete;
  final ValueChanged<Task> onChanged;

  const AllTasksScreen({super.key, required this.tasks, required this.onEdit, required this.onDelete, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final pending = tasks.where((task) => task.status != TaskStatus.completed).length;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Todas as tarefas', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text('$pending tarefas ainda precisam da sua atenção.', style: TextStyle(color: Colors.blueGrey.shade200)),
      const SizedBox(height: 26),
      if (tasks.isEmpty) const EmptyState() else ...tasks.map((task) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TaskCard(
          task: task,
          onEdit: () => onEdit(task),
          onDelete: () => onDelete(task),
          onStatusChanged: (status) { if (status != null) { task.status = status; onChanged(task); } },
        ),
      )),
    ]);
  }
}
