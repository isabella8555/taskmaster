import 'package:flutter/material.dart';
import '../models/task.dart';
import '../utils/task_labels.dart';

class CalendarScreen extends StatefulWidget {
  final List<Task> tasks;
  const CalendarScreen({super.key, required this.tasks});
  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _selected = DateTime(2026, 10, 20);
  DateTime _month = DateTime(2026, 10);

  List<Task> get _selectedTasks => widget.tasks.where((task) => task.dueDate != null && task.dueDate!.year == _selected.year && task.dueDate!.month == _selected.month && task.dueDate!.day == _selected.day).toList();

  @override
  Widget build(BuildContext context) {
    final first = DateTime(_month.year, _month.month, 1);
    final days = DateTime(_month.year, _month.month + 1, 0).day;
    final offset = first.weekday - 1;
    final cells = List<DateTime?>.filled(offset, null, growable: true)
      ..addAll(List.generate(days, (i) => DateTime(_month.year, _month.month, i + 1)));
    while (cells.length % 7 != 0) {
      cells.add(null);
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Calendário', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text('Visualize os prazos das suas tarefas.', style: TextStyle(color: Colors.blueGrey.shade200)),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(18), decoration: _box(), child: Column(children: [
        Row(children: [IconButton(onPressed: () => setState(() => _month = DateTime(_month.year, _month.month - 1)), icon: const Icon(Icons.chevron_left)), Expanded(child: Center(child: Text('${_monthName(_month.month)} ${_month.year}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)))), IconButton(onPressed: () => setState(() => _month = DateTime(_month.year, _month.month + 1)), icon: const Icon(Icons.chevron_right))]),
        const SizedBox(height: 12),
        Row(
          children: [
            for (final day in const ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'])
              Expanded(
                child: Center(
                  child: Text(
                    day,
                    style: TextStyle(color: Colors.blueGrey.shade300, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 8),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: cells.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 6, crossAxisSpacing: 6), itemBuilder: (_, index) => _dayCell(cells[index])),
      ])),
      const SizedBox(height: 24),
      Text('Tarefas de ${_selected.day} de ${_monthName(_selected.month)}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (_selectedTasks.isEmpty) Text('Nenhuma tarefa com prazo neste dia.', style: TextStyle(color: Colors.blueGrey.shade300)) else ..._selectedTasks.map((task) => ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.task_alt, color: Color(0xFF9B7BFF)), title: Text(task.title), subtitle: Text('${categoryLabel(task.category)} • ${statusLabel(task.status)}'))),
    ]);
  }

  Widget _dayCell(DateTime? date) {
    if (date == null) return const SizedBox.shrink();
    final hasTask = widget.tasks.any((task) => task.dueDate?.year == date.year && task.dueDate?.month == date.month && task.dueDate?.day == date.day);
    final selected = date.year == _selected.year && date.month == _selected.month && date.day == _selected.day;
    return InkWell(onTap: () => setState(() => _selected = date), borderRadius: BorderRadius.circular(10), child: Container(decoration: BoxDecoration(color: selected ? const Color(0xFF8B5CF6) : hasTask ? const Color(0xFF2A2450) : const Color(0xFF1B2840), borderRadius: BorderRadius.circular(10)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('${date.day}', style: TextStyle(fontWeight: selected ? FontWeight.bold : FontWeight.normal)), if (hasTask) const Padding(padding: EdgeInsets.only(top: 3), child: Icon(Icons.circle, size: 5, color: Color(0xFFFBBF24)))])));
  }

  BoxDecoration _box() => BoxDecoration(color: const Color(0xFF151F34), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF24314B)));
  String _monthName(int month) => const ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'][month];
}
