import 'package:flutter/material.dart';
import '../models/task.dart';
import '../utils/task_labels.dart';

class TaskCard extends StatelessWidget {
  final Task task;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<TaskStatus?> onStatusChanged;

  const TaskCard({super.key, required this.task, required this.onEdit, required this.onDelete, required this.onStatusChanged});

  @override
  Widget build(BuildContext context) {
    final completed = task.status == TaskStatus.completed;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF151F34),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: completed ? const Color(0xFF245344) : const Color(0xFF24314B)),
      ),
      child: Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(task.title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, decoration: completed ? TextDecoration.lineThrough : null, color: completed ? Colors.blueGrey.shade400 : Colors.white))),
              PriorityBadge(task.priority),
            ]),
            const SizedBox(height: 8),
            Text(task.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.blueGrey.shade300)),
          ])),
          PopupMenuButton<String>(onSelected: (value) { if (value == 'edit') onEdit(); if (value == 'delete') onDelete(); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Editar')), PopupMenuItem(value: 'delete', child: Text('Excluir'))]),
        ]),
        const SizedBox(height: 18),
        Wrap(spacing: 10, runSpacing: 10, children: [
          TaskTag(Icons.folder_outlined, categoryLabel(task.category)),
          if (task.dueDate != null) TaskTag(Icons.calendar_today_outlined, formatDate(task.dueDate!)),
          StatusDropdown(task.status, onStatusChanged),
        ]),
      ]),
    );
  }
}

class PriorityBadge extends StatelessWidget {
  final TaskPriority priority;
  const PriorityBadge(this.priority, {super.key});
  @override
  Widget build(BuildContext context) {
    final color = priority == TaskPriority.high ? const Color(0xFFF87171) : priority == TaskPriority.medium ? const Color(0xFFFBBF24) : const Color(0xFF60A5FA);
    return Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: color.withValues(alpha: .14), borderRadius: BorderRadius.circular(20)), child: Text(priorityLabel(priority).toUpperCase(), style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)));
  }
}

class TaskTag extends StatelessWidget {
  final IconData icon;
  final String label;
  const TaskTag(this.icon, this.label, {super.key});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: const Color(0xFF1D2A43), borderRadius: BorderRadius.circular(8)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: Colors.blueGrey.shade300), const SizedBox(width: 6), Text(label, style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade200))]));
}

class StatusDropdown extends StatelessWidget {
  final TaskStatus status;
  final ValueChanged<TaskStatus?> onChanged;
  const StatusDropdown(this.status, this.onChanged, {super.key});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 8), decoration: BoxDecoration(color: const Color(0xFF1D2A43), borderRadius: BorderRadius.circular(8)), child: DropdownButton<TaskStatus>(value: status, underline: const SizedBox(), isDense: true, dropdownColor: const Color(0xFF1D2A43), style: const TextStyle(fontSize: 12, color: Colors.white), items: TaskStatus.values.map((s) => DropdownMenuItem(value: s, child: Text(statusLabel(s)))).toList(), onChanged: onChanged));
}
