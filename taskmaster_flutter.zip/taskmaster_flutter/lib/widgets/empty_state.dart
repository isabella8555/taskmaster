import 'package:flutter/material.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(44),
        decoration: BoxDecoration(color: const Color(0xFF151F34), borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          Icon(Icons.search_off, size: 48, color: Colors.blueGrey.shade400),
          const SizedBox(height: 12),
          const Text('Nenhuma tarefa encontrada', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Tente ajustar os filtros ou cadastrar uma nova tarefa.', style: TextStyle(color: Colors.blueGrey.shade300)),
        ]),
      );
}
