import 'package:flutter/material.dart';

class FilterDropdown<T> extends StatelessWidget {
  final String label;
  final T? value;
  final List<T> items;
  final String Function(T) text;
  final ValueChanged<T?> onChanged;

  const FilterDropdown({super.key, required this.label, required this.value, required this.items, required this.text, required this.onChanged});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 150,
        height: 58,
        child: DropdownButtonFormField<T>(
          initialValue: value,
          isDense: true,
          isExpanded: true,
          decoration: InputDecoration(labelText: label, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
          dropdownColor: const Color(0xFF1D2A43),
          items: [
            DropdownMenuItem<T>(value: null, child: const Text('Todos')),
            ...items.map((item) => DropdownMenuItem<T>(value: item, child: Text(text(item)))),
          ],
          onChanged: onChanged,
        ),
      );
}
