import 'package:flutter/material.dart';

class NotificationPanel extends StatelessWidget {
  const NotificationPanel({super.key});

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Row(children: [
          Icon(Icons.notifications, color: Color(0xFFB49BFF)),
          SizedBox(width: 10),
          Text('Notificações')
        ]),
        content: const SizedBox(
            width: 460,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              _NotificationTile(
                  icon: Icons.warning_amber_rounded,
                  color: Color(0xFFFBBF24),
                  title: 'Prazo se aproximando',
                  message: 'Finalizar trabalho escolar vence amanhã.',
                  time: 'Há 10 min'),
              _NotificationTile(
                  icon: Icons.check_circle_outline,
                  color: Color(0xFF34D399),
                  title: 'Tarefa concluída',
                  message: 'Fazer caminhada foi marcada como concluída.',
                  time: 'Há 1 h'),
              _NotificationTile(
                  icon: Icons.auto_awesome,
                  color: Color(0xFF60A5FA),
                  title: 'Resumo do dia',
                  message: 'Você tem 2 tarefas pendentes para hoje.',
                  time: 'Hoje'),
            ])),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fechar'))
        ],
      );
}

class _NotificationTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String message;
  final String time;
  const _NotificationTile(
      {required this.icon,
      required this.color,
      required this.title,
      required this.message,
      required this.time});
  @override
  Widget build(BuildContext context) => ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 6),
      leading: CircleAvatar(
          backgroundColor: color.withValues(alpha: .15),
          child: Icon(icon, color: color)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(message),
      trailing: Text(time,
          style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade300)));
}
