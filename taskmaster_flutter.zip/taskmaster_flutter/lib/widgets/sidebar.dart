import 'package:flutter/material.dart';

enum AppSection { dashboard, allTasks, calendar, settings }

class SideBar extends StatelessWidget {
  final AppSection selected;
  final ValueChanged<AppSection> onSelected;
  const SideBar({super.key, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) => Container(
        width: 238,
        padding: const EdgeInsets.fromLTRB(24, 34, 18, 24),
        decoration: const BoxDecoration(color: Color(0xFF111B2E), border: Border(right: BorderSide(color: Color(0xFF24314B)))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.check_circle_outline, color: Color(0xFF9B7BFF), size: 32), const SizedBox(width: 10), Text('TASKMASTER', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, letterSpacing: 1.2))]),
          const SizedBox(height: 50),
          _item(Icons.dashboard_outlined, 'Dashboard', AppSection.dashboard),
          _item(Icons.list_alt_outlined, 'Todas as tarefas', AppSection.allTasks),
          _item(Icons.calendar_month_outlined, 'Calendário', AppSection.calendar),
          const Spacer(),
          _item(Icons.settings_outlined, 'Configurações', AppSection.settings),
        ]),
      );

  Widget _item(IconData icon, String label, AppSection section) {
    final active = selected == section;
    return Padding(padding: const EdgeInsets.only(bottom: 8), child: InkWell(onTap: () => onSelected(section), borderRadius: BorderRadius.circular(10), child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13), decoration: BoxDecoration(color: active ? const Color(0xFF30245A) : Colors.transparent, borderRadius: BorderRadius.circular(10)), child: Row(children: [Icon(icon, size: 20, color: active ? const Color(0xFFB49BFF) : Colors.blueGrey.shade300), const SizedBox(width: 12), Text(label, style: TextStyle(color: active ? Colors.white : Colors.blueGrey.shade300))]))));
  }
}
