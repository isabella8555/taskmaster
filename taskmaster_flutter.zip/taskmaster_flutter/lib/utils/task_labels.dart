import '../models/task.dart';

String priorityLabel(TaskPriority value) => switch (value) {
  TaskPriority.high => 'Alta',
  TaskPriority.medium => 'Média',
  TaskPriority.low => 'Baixa',
};

String statusLabel(TaskStatus value) => switch (value) {
  TaskStatus.pending => 'Pendente',
  TaskStatus.inProgress => 'Em andamento',
  TaskStatus.completed => 'Concluída',
};

String categoryLabel(TaskCategory value) => switch (value) {
  TaskCategory.studies => 'Estudos',
  TaskCategory.work => 'Trabalho',
  TaskCategory.personal => 'Pessoal',
  TaskCategory.health => 'Saúde',
  TaskCategory.other => 'Outros',
};

String formatDate(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
